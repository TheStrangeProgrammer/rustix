@extends('main')
@section('content')

    <p>{{ $error }}</p>

@endsection
@section('title', 'Error')
