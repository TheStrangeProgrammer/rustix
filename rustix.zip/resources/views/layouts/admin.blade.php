@extends('main')
@section('content')

<div class="d-flex m-5 cola">asdf</div>

@endsection
@section('title', 'admin')

@section('css')
    <link rel="stylesheet" type="text/css" href="{{ asset('css/layouts/admin.css') }}">
@endsection
@section('js')
    <script src="{{ asset('js/layouts/admin.js') }}"></script>
@endsection
