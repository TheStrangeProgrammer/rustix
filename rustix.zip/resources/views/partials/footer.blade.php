<footer class="mt-auto footer">
    Created by TheStranger&Tomi
</footer>
