<?php
return [
    "steamAppId"=>252490,
    "steamContext"=>2,
    "depositId" => 76561199224197839,
    "depositInfo" => [
        "username"=> "labalamuc84",
        "password"=> "Mihaibingo1",
        "mobileAuth"=> [
            "sharedSecret"=> "f0KS077xz3VFMUxuhVwG4RVyn7A=",
            "identitySecret" => "VEY3hCgkOiNcuuVJFQ9wR82c4Eo=",
            "deviceId"=> "android:31802749-752d-461b-98d6-29463a7c1a9c"
        ]
    ],
    "bot1Info" => [
        "username"=> "labalamuc81",
        "password"=> "Mihaibingo1",
        "mobileAuth"=> [
            "sharedSecret"=> "f0KS077xz3VFMUxuhVwG4RVyn7A=",
            "identitySecret" => "VEY3hCgkOiNcuuVJFQ9wR82c4Eo=",
            "deviceId"=> "android:31802749-752d-461b-98d6-29463a7c1a9c"
        ]
    ],
    "bot2Info" => [
        "username"=> "labalamuc82",
        "password"=> "Mihaibingo1",
        "mobileAuth"=> [
            "sharedSecret"=> "f0KS077xz3VFMUxuhVwG4RVyn7A=",
            "identitySecret" => "VEY3hCgkOiNcuuVJFQ9wR82c4Eo=",
            "deviceId"=> "android:31802749-752d-461b-98d6-29463a7c1a9c"
        ]
    ],
    "bot3Info" => [
        "username"=> "labalamuc83",
        "password"=> "Mihaibingo1",
        "mobileAuth"=> [
            "sharedSecret"=> "f0KS077xz3VFMUxuhVwG4RVyn7A=",
            "identitySecret" => "VEY3hCgkOiNcuuVJFQ9wR82c4Eo=",
            "deviceId"=> "android:31802749-752d-461b-98d6-29463a7c1a9c"
        ]
    ],
    "userInventoryRefresh" => 30,
    "depositInventoryRefresh" => 60,
    "depositInventory"=>"test",


];
