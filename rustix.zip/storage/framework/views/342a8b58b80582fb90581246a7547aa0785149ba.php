<?php $__env->startSection('content'); ?>
    <?php if($inventory['success'] == true): ?>
        <div class="d-flex flex-column flex-fill h-100">
            <div class="flex-fill inventory-wrapper">
                <div class="d-flex flex-wrap inventory">

                    <?php $__currentLoopData = $inventory['inventory']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-column align-items-center border border-dark m-2 item">
                            <p class="d-none item-id"><?php echo e($item['id']); ?></p>
                            <p class="d-none item-quantity"><?php echo e($item['amount']); ?></p>

                            <p class="text-center fw-bold mt-1"><?php echo e($item['name']); ?></p>
                            <img src="<?php echo e($item['icon_url']); ?>" width="100px">



                            <div class="d-flex flex-column item-info">
                                <p class="ms-2">Amount: <?php echo e($item['amount']); ?></p>
                                <p class="ms-2 me-2 ">Price: <?php echo e($item['price']); ?></p>
                            </div>

                            <div class="d-flex">
                                <div class="d-none input-group input-group-sm item-quantity-input">
                                    <span class="input-group-text">Quantity</span>
                                    <input class="form-control" type="number" min="0" max="0" value="0">
                                </div>
                            </div>


                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="d-flex container-fluid  fw-bold inventory-sell p-2" style="background-color: #141620">
                <form class="d-inline mx-auto" method="POST" action="<?php echo e(URL::route('depositItems')); ?>">
                    <?php echo csrf_field(); ?>
                    <p class="text-white d-inline me-5">Total: </p>
                    <input id="item-list" class="d-none" type="text" name="itemList">
                    <input class="text-white px-4 py-2" style="background-color:#14DB1A " id="submit-item-list"
                        type="submit" value="SELL">
                </form>
                </li>
            </div>
        </div>
    <?php else: ?>
        <p>You do not have the game or your inventory is private</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Inventory'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/layouts/inventory.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/layouts/inventory.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git_work\rustix\rustix\resources\views/layouts/inventory.blade.php ENDPATH**/ ?>