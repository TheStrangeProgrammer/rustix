<?php echo $__env->make('partials.left_sidebar.alt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.left_sidebar.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.left_sidebar.tos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-flex flex-column sidebar display-media">

    <button class="p-1 mt-3" data-bs-toggle="modal" data-bs-target="#TOS">TOS</button>
    <button class="p-1 mt-3" data-bs-toggle="modal" data-bs-target="#FAQ">FAQ</button>
    <button class="p-1 mt-3" data-bs-toggle="modal" data-bs-target="#ALT">ALT</button>

    <button class="mt-auto p-1"><i class="fas fa-arrow-left mb15"></i></button>
</div>

<div class="d-flex flex-column flex-fill display-media">
    <div class="d-flex chat-top">
        <p class="pt-2 ps-2 fw-bold">ENG <span class="green">63 </span>ONLINE</p>

        <button class="fab fa-discord pad10 margin"></button>
        <button class="fab fa-twitter pad10 me-1 ms-2"></button>
        <button class="fab fa-instagram pad10 mx-1"></button>
    </div>

    <?php if(Auth::check()): ?>
        <chat class="flex-fill" user="<?php echo e(Auth::user()->name); ?>"></chat>
    <?php else: ?>
        <guestchat class="flex-fill"></guestchat>
    <?php endif; ?>



</div>
<?php /**PATH D:\git_work\rustix\resources\views/partials/left_sidebar.blade.php ENDPATH**/ ?>