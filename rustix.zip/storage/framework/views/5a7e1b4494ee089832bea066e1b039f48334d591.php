<!DOCTYPE html>

<html class="h-100">

<head>
    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="h-100 body">
    <div id="app" class="d-flex flex-column h-100">
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="sidebar-and-content" class="d-flex h-100 w-100">
            <section class="d-flex left-sidebar h-100 ">
                <?php echo $__env->make('partials.left_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
            <div id="overlay" class="justify-content-center align-items-center">
                <div class="spinner-border text-light" style="width: 10rem; height: 10rem;" role="status">
                </div>
            </div>
            <main class="main">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>

        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH D:\git_work\rustix\rustix\resources\views/main.blade.php ENDPATH**/ ?>