<footer class="mt-auto footer">
    Created by TheStranger&Tomi
</footer>
<?php /**PATH D:\git_work\rustix\resources\views/partials/footer.blade.php ENDPATH**/ ?>