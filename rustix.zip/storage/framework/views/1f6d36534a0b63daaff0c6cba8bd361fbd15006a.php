<?php $__env->startSection('content'); ?>
    <?php if($data['success']==true): ?>
        <div class="d-flex flex-wrap inventory">
            <?php $__currentLoopData = $data['rgInventory']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $itemDesc = $data['rgDescriptions'][$item['classid'].'_'.$item['instanceid']]
                ?>
                <div class="item" style="background-image: url(https://steamcommunity-a.akamaihd.net/economy/image/<?php echo e($itemDesc['icon_url']); ?>);">
                    <p><?php echo e($itemDesc['name']); ?></p>
                    <p><?php echo e($item['amount']); ?></p>
                </div>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
    <p>You do not have the game or your inventory is private</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title',"Inventory"); ?>

<script>
    document.getElementsByClassName("item").addEventListener("click", selectItem);
    function selectItem() {
        this.classList.add("mystyle");
    }
</script>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git_work\rustix\rustix\resources\views/layouts/deposit.blade.php ENDPATH**/ ?>