
<?php $__env->startSection('content'); ?>

    <div class="flex-container">
        <div class="d-flex flex-column h-50 flex-child ms-3">
            <div style="border: 2px solid #25c52a ">
                <h3 class="max-width: 100% text-center py-3" style="background-color: #0d0e14">Profile</h3>
                <p class="ms-3 my-4 fw-bold">Total Deposited: <?php echo e($totalDeposit); ?></p>
                <p class="ms-3 my-4 fw-bold">Total Spent: <?php echo e($totalSpent); ?></p>
                <p class="ms-3 my-4 fw-bold">Total Withdrawed: <?php echo e($totalWithdraw); ?></p>
                <form class="ms-3 my-4 fw-bold" method="POST" action="<?php echo e(URL::route('setTradeUrl')); ?>">
                    <?php echo csrf_field(); ?>
                    <input name="tradeUrl" type="text">
                    <input type="submit" value="Set Trade URL">
                </form>
            </div>
            <div class="mt-4 profile-borders">
                <div>
                    <h3 class="max-width: 100%  mx-auto py-3 text-center" style="background-color: #0d0e14">Referrals</h3>
                    <p class="ms-3 my-4 fw-bold">Your Code: <?php echo e($referralCode); ?></p>
                    <?php if(Auth::user()->referredBy == null): ?>
                        <form class="ms-3 my-4 align-middle fw-bold" method="POST"
                            action="<?php echo e(URL::route('setReferral')); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="referrerCode" type="text">
                            <input type="submit" value="Set Code">
                        </form>
                    <?php else: ?>
                        <p>You are already referred to: <?php echo e($referrerName); ?></p>
                    <?php endif; ?>
                </div>
                <p class="ms-3 py-2 fw-bold">Users Referred By You:</p>
                <div class="inventory-wrapper">
                    <div class="d-flex flex-wrap inventory">
                        <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="ms-2 me-2"><?php echo e($referal['name']); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex flex-column h-50 flex-child magenta me-3">

            <div>
                <h3 class="max-width: 100%  mx-auto py-3 text-center mb-0 history-custom">History</h3>

            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title', 'Profile'); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/layouts/profile.css')); ?>">
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git_work\rustix\rustix\resources\views/layouts/profile.blade.php ENDPATH**/ ?>