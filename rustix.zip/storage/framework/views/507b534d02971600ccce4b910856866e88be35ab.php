<?php $__env->startSection('content'); ?>

    <p><?php echo e($error); ?></p>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title',"Error"); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git_work\rustix\rustix\resources\views/layouts/error.blade.php ENDPATH**/ ?>