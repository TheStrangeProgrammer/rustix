
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php echo $__env->yieldContent('js'); ?>

<?php /**PATH D:\git_work\rustix\rustix\resources\views/scripts.blade.php ENDPATH**/ ?>