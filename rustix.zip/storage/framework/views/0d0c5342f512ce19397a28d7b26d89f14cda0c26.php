
<?php $__env->startSection('content'); ?>

    <div class="m-4">
        <div class="card-game">
          <div class=" card-img-top-wrapper">
            <div class="d-flex card-overlay">
                <a href="<?php echo e(URL::route('roulette')); ?>" class="play-button m-auto py-3" style="color: white;">PLAY</a>
            </div>
          </div>
          <div class="card-body">
            <h5 class="game-text">ROULETTE</h5>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Home'); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git_work\rustix\resources\views/layouts/home.blade.php ENDPATH**/ ?>